import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import db from "../db.js";

const router = express.Router();

// 회원가입
router.post("/signup", async (req, res) => {
  const { name, email, password } = req.body;

  const hashed = await bcrypt.hash(password, 10);

  await db.query(
    "INSERT INTO users(name, email, password) VALUES (?, ?, ?)",
    [name, email, hashed]
  );

  res.json({ message: "User registered" });
});

// 로그인
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  const [users] = await db.query("SELECT * FROM users WHERE email=?", [email]);

  if (users.length === 0)
    return res.status(400).json({ message: "Email not found" });

  const user = users[0];

  const match = await bcrypt.compare(password, user.password);

  if (!match) return res.status(400).json({ message: "Wrong password" });

  const token = jwt.sign(
    { id: user.id, email: user.email },
    "SECRET_KEY_123",
    { expiresIn: "7d" }
  );

  res.json({ message: "Login success", token });
});

export default router;
